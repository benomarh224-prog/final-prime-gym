'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAppStore } from '@/lib/store';
import { features, machineGuides, workoutPrograms } from '@/lib/data';
import {
  Bot, Dumbbell, BarChart3, Apple, Users, MapPin,
  ArrowRight, Zap, Shield, Flame, Target, TrendingUp,
  ChevronRight, ChevronDown, Clock, Calendar, Cpu,
  AlertTriangle, Lightbulb, DumbbellIcon,
} from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  bot: <Bot className="h-6 w-6" />,
  dumbbell: <Dumbbell className="h-6 w-6" />,
  chart: <BarChart3 className="h-6 w-6" />,
  apple: <Apple className="h-6 w-6" />,
  users: <Users className="h-6 w-6" />,
  'map-pin': <MapPin className="h-6 w-6" />,
};

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.6, ease: 'easeOut' },
  }),
};

const difficultyColor: Record<string, string> = {
  beginner: 'bg-green-500/10 text-green-500 border-green-500/20',
  intermediate: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
  advanced: 'bg-red-500/10 text-red-500 border-red-500/20',
};

const levelColor: Record<string, string> = {
  beginner: 'bg-green-500/10 text-green-400 border-green-500/30',
  intermediate: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
  advanced: 'bg-red-500/10 text-red-400 border-red-500/30',
};

export function HomePage() {
  const { navigate } = useAppStore();
  const [selectedMachine, setSelectedMachine] = useState<string | null>(null);
  const [selectedProgram, setSelectedProgram] = useState<string | null>(null);

  const activeMachine = machineGuides.find(m => m.id === selectedMachine);
  const activeProgram = workoutPrograms.find(p => p.id === selectedProgram);

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center">
        <div className="absolute inset-0">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{ backgroundImage: "url('/images/hero-bg.png')" }}
          />
          <div className="hero-overlay absolute inset-0" />
        </div>

        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 rounded-full bg-primary/40"
              style={{
                left: `${15 + i * 15}%`,
                top: `${20 + (i % 3) * 25}%`,
              }}
              animate={{
                y: [0, -30, 0],
                opacity: [0.2, 0.6, 0.2],
              }}
              transition={{
                duration: 3 + i * 0.5,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          ))}
        </div>

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <Badge variant="secondary" className="mb-6 px-4 py-1.5 text-sm bg-primary/10 border-primary/20 text-primary">
              <Zap className="h-3 w-3 mr-1.5" />
              AI-Powered Fitness
            </Badge>

            <h1 className="text-4xl sm:text-5xl md:text-7xl font-black tracking-tight mb-6">
              Transform Your
              <br />
              <span className="gradient-text">Body & Mind</span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              Get personalized workout plans, real-time AI coaching, nutrition guidance,
              and smart progress tracking — all in one platform.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                size="lg"
                onClick={() => navigate('workouts')}
                className="h-14 px-8 text-base rounded-xl neon-glow gap-2 font-semibold"
              >
                Start Training
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => navigate('ai-coach')}
                className="h-14 px-8 text-base rounded-xl gap-2 font-semibold glass border-white/20 text-foreground hover:bg-white/10"
              >
                <Bot className="h-4 w-4" />
                Try AI Coach
              </Button>
            </div>

            <motion.div
              className="flex flex-wrap items-center justify-center gap-8 mt-16"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
            >
              {[
                { value: '500+', label: 'Exercises' },
                { value: '6', label: 'Gym Machines' },
                { value: '6', label: 'Programs' },
                { value: '24/7', label: 'AI Support' },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-2xl sm:text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex justify-center pt-2">
            <div className="w-1.5 h-3 rounded-full bg-primary/60" />
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            custom={0}
          >
            <Badge variant="secondary" className="mb-4">Features</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
              Everything You Need to <span className="gradient-text">Succeed</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              A complete fitness ecosystem designed to support your journey from day one.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.id}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                custom={i}
              >
                <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 h-full border-border/50">
                  <CardContent className="p-6">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                      {iconMap[feature.icon]}
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why FitForge */}
      <section className="py-20 sm:py-28 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <Badge variant="secondary" className="mb-4">Why FitForge</Badge>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-6">
                Not Just Another <span className="gradient-text">Fitness App</span>
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                FitForge combines cutting-edge AI with proven fitness methodologies to create
                a truly personalized experience. Our AI Coach learns from your progress and
                adapts your plans in real-time.
              </p>
              <div className="space-y-4">
                {[
                  { icon: <Target className="h-5 w-5 text-primary" />, title: 'Personalized Plans', desc: 'AI creates custom workouts based on your goals and fitness level' },
                  { icon: <TrendingUp className="h-5 w-5 text-primary" />, title: 'Adaptive Training', desc: 'Plans evolve as you progress, ensuring continuous improvement' },
                  { icon: <Flame className="h-5 w-5 text-primary" />, title: 'Motivation System', desc: 'Daily challenges, streaks, and AI-powered encouragement' },
                  { icon: <Shield className="h-5 w-5 text-primary" />, title: 'Expert Guidance', desc: 'Built by certified trainers and sports scientists' },
                ].map((item) => (
                  <div key={item.title} className="flex gap-4 items-start">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden neon-glow">
                <div
                  className="aspect-[4/3] bg-cover bg-center"
                  style={{ backgroundImage: "url('/images/workout-strength.png')" }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <Card className="glass">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">Today&apos;s Workout</p>
                          <p className="text-xs text-muted-foreground">Upper Body Strength</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-primary">85%</p>
                          <p className="text-xs text-muted-foreground">Complete</p>
                        </div>
                      </div>
                      <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-primary rounded-full"
                          initial={{ width: 0 }}
                          whileInView={{ width: '85%' }}
                          viewport={{ once: true }}
                          transition={{ duration: 1.5, ease: 'easeOut', delay: 0.5 }}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How to Use Machines */}
      <section className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            custom={0}
          >
            <Badge variant="secondary" className="mb-4">
              <Cpu className="h-3 w-3 mr-1" />
              Machine Guides
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
              How to Use <span className="gradient-text">Gym Machines</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Step-by-step guides for the most popular gym machines. Learn proper form,
              avoid common mistakes, and get the most out of every exercise.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Machine Selection List */}
            <div className="lg:col-span-2 space-y-3">
              {machineGuides.map((machine, i) => (
                <motion.div
                  key={machine.id}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUp}
                  custom={i}
                >
                  <button
                    onClick={() => setSelectedMachine(selectedMachine === machine.id ? null : machine.id)}
                    className={`w-full text-left p-4 rounded-xl border transition-all duration-200 group ${
                      selectedMachine === machine.id
                        ? 'border-primary bg-primary/5 shadow-md'
                        : 'border-border/50 bg-card hover:border-primary/50 hover:bg-muted/30'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                          selectedMachine === machine.id ? 'bg-primary text-primary-foreground' : 'bg-primary/10 text-primary'
                        } transition-colors`}>
                          <DumbbellIcon className="h-5 w-5" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm">{machine.name}</h4>
                          <p className="text-xs text-muted-foreground">{machine.muscleGroup}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={`text-[10px] px-2 py-0 ${difficultyColor[machine.difficulty]}`}>
                          {machine.difficulty}
                        </Badge>
                        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-200 ${
                          selectedMachine === machine.id ? 'rotate-180' : ''
                        }`} />
                      </div>
                    </div>
                  </button>
                </motion.div>
              ))}
            </div>

            {/* Machine Detail Panel */}
            <div className="lg:col-span-3">
              <AnimatePresence mode="wait">
                {activeMachine ? (
                  <motion.div
                    key={activeMachine.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className="space-y-4"
                  >
                    {/* Machine Hero */}
                    <div className="relative rounded-2xl overflow-hidden">
                      <div
                        className="aspect-[16/7] bg-cover bg-center"
                        style={{ backgroundImage: `url('${activeMachine.image}')` }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className="bg-primary text-primary-foreground">{activeMachine.category}</Badge>
                          <Badge variant="outline" className={`text-xs ${difficultyColor[activeMachine.difficulty]}`}>
                            {activeMachine.difficulty}
                          </Badge>
                        </div>
                        <h3 className="text-xl font-bold">{activeMachine.name}</h3>
                      </div>
                    </div>

                    {/* Setup */}
                    <Card className="border-border/50">
                      <CardContent className="p-5">
                        <div className="flex items-center gap-2 mb-2">
                          <BarChart3 className="h-4 w-4 text-primary" />
                          <h4 className="font-semibold text-sm">Setup</h4>
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">{activeMachine.setup}</p>
                      </CardContent>
                    </Card>

                    {/* Steps */}
                    <Card className="border-border/50">
                      <CardContent className="p-5">
                        <div className="flex items-center gap-2 mb-3">
                          <Target className="h-4 w-4 text-primary" />
                          <h4 className="font-semibold text-sm">Step-by-Step Instructions</h4>
                        </div>
                        <div className="space-y-2">
                          {activeMachine.steps.map((step, i) => (
                            <div key={i} className="flex gap-3 items-start">
                              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-bold">
                                {i + 1}
                              </span>
                              <p className="text-sm text-muted-foreground leading-relaxed">{step}</p>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Common Mistakes */}
                    <Card className="border-destructive/20">
                      <CardContent className="p-5">
                        <div className="flex items-center gap-2 mb-3">
                          <AlertTriangle className="h-4 w-4 text-destructive" />
                          <h4 className="font-semibold text-sm text-destructive">Common Mistakes</h4>
                        </div>
                        <div className="space-y-2">
                          {activeMachine.commonMistakes.map((mistake, i) => (
                            <div key={i} className="flex gap-2 items-start">
                              <span className="text-destructive mt-0.5 text-xs">✕</span>
                              <p className="text-sm text-muted-foreground leading-relaxed">{mistake}</p>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Pro Tip */}
                    <Card className="border-primary/20 bg-primary/5">
                      <CardContent className="p-5">
                        <div className="flex items-center gap-2 mb-2">
                          <Lightbulb className="h-4 w-4 text-primary" />
                          <h4 className="font-semibold text-sm text-primary">Pro Tip</h4>
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">{activeMachine.proTip}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ) : (
                  <motion.div
                    key="placeholder"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <Card className="h-full min-h-[400px] flex items-center justify-center border-dashed border-2 border-border/50 bg-muted/10">
                      <CardContent className="p-8 text-center">
                        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary mx-auto mb-4">
                          <DumbbellIcon className="h-8 w-8" />
                        </div>
                        <h3 className="font-semibold text-lg mb-2">Select a Machine</h3>
                        <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                          Click on any machine from the list to view detailed instructions, common mistakes, and pro tips.
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </section>

      {/* Workout Programs */}
      <section className="py-20 sm:py-28 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            custom={0}
          >
            <Badge variant="secondary" className="mb-4">
              <Calendar className="h-3 w-3 mr-1" />
              Programs
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
              Choose Your <span className="gradient-text">Workout Program</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Professionally designed programs for every fitness level. Each includes a full weekly
              schedule, exercise breakdowns, and progressive structure.
            </p>
          </motion.div>

          {/* Program Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
            {workoutPrograms.map((program, i) => (
              <motion.div
                key={program.id}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                custom={i}
              >
                <button
                  onClick={() => setSelectedProgram(selectedProgram === program.id ? null : program.id)}
                  className="w-full text-left"
                >
                  <Card className={`group h-full transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
                    selectedProgram === program.id
                      ? 'border-primary shadow-md neon-glow'
                      : 'border-border/50'
                  }`}>
                    <div className="relative">
                      <div
                        className="h-40 bg-cover bg-center rounded-t-xl"
                        style={{ backgroundImage: `url('${program.image}')` }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent rounded-t-xl" />
                      <div className="absolute top-3 left-3">
                        <Badge variant="outline" className={`text-xs backdrop-blur-sm bg-background/80 ${levelColor[program.level]}`}>
                          {program.level}
                        </Badge>
                      </div>
                      <div className="absolute bottom-3 left-3 right-3">
                        <h3 className="font-bold text-lg">{program.name}</h3>
                      </div>
                    </div>
                    <CardContent className="p-4 pt-3">
                      <p className="text-xs text-muted-foreground leading-relaxed mb-3 line-clamp-2">
                        {program.description}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" /> {program.duration}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" /> {program.daysPerWeek} days/week
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="h-3 w-3" /> {program.goal.split(' ').slice(0, 2).join(' ')}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {program.highlights.slice(0, 3).map(h => (
                          <Badge key={h} variant="secondary" className="text-[10px] px-2 py-0">{h}</Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </button>
              </motion.div>
            ))}
          </div>

          {/* Program Schedule Detail */}
          <AnimatePresence mode="wait">
            {activeProgram ? (
              <motion.div
                key={activeProgram.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.4 }}
                className="overflow-hidden"
              >
                <Card className="border-primary/30">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h3 className="text-xl font-bold">{activeProgram.name}</h3>
                        <p className="text-sm text-muted-foreground">{activeProgram.description}</p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => navigate('workouts')}
                        className="neon-glow gap-1"
                      >
                        Start Program
                        <ArrowRight className="h-3 w-3" />
                      </Button>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-6">
                      {activeProgram.highlights.map(h => (
                        <Badge key={h} variant="secondary" className="text-xs">{h}</Badge>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {activeProgram.schedule.map((day) => (
                        <div key={day.day} className="rounded-xl border border-border/50 p-4 bg-muted/20">
                          <div className="flex items-center justify-between mb-3">
                            <h4 className="font-semibold text-sm">{day.day}</h4>
                            <Badge className="text-xs bg-primary/10 text-primary border-primary/20">{day.focus}</Badge>
                          </div>
                          <div className="space-y-1.5">
                            {day.exercises.map((ex, i) => (
                              <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                                <ChevronRight className="h-3 w-3 mt-0.5 text-primary shrink-0" />
                                <span>{ex}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            className="relative rounded-3xl overflow-hidden"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: "url('/images/hero-bg.png')" }}
            />
            <div className="hero-overlay absolute inset-0" />
            <div className="relative z-10 text-center py-16 sm:py-24 px-4">
              <h2 className="text-3xl sm:text-5xl font-black mb-4">
                Ready to <span className="gradient-text">Start?</span>
              </h2>
              <p className="text-muted-foreground max-w-lg mx-auto mb-8 text-lg">
                Choose a program, learn the machines, and let our AI Coach guide you every step of the way.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  size="lg"
                  onClick={() => navigate('workouts')}
                  className="h-14 px-10 text-base rounded-xl neon-glow gap-2 font-semibold"
                >
                  <Dumbbell className="h-4 w-4" />
                  Start Your Journey
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => navigate('ai-coach')}
                  className="h-14 px-10 text-base rounded-xl gap-2 font-semibold glass border-white/20 text-foreground hover:bg-white/10"
                >
                  <Bot className="h-4 w-4" />
                  Ask AI Coach
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
